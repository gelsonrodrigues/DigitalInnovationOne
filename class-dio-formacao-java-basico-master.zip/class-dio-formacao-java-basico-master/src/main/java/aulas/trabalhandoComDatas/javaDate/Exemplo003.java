package aulas.trabalhandoComDatas.javaDate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *  Exemplo de utilização dos metodos after e before
 */
public class Exemplo003 {

    public static void main(String[] args) throws ParseException {

        Date dataNoPassado = new Date(1513124807691L);
        //Tue Dec 12 22:26:47 BRST 2017

        Date dataNoFuturo = new Date(1613124807691L);
        //Fri Feb 12 08:13:27 BRST 2021

        /** Comparando se a dataNoPassado é posterior a dataNoFuturo */
        boolean isAfter = dataNoPassado.after(dataNoFuturo);

        System.out.println(isAfter);
        //false

        /** Comparando se a dataNoPassado é anterior a dataNoFuturo */
        boolean isBefore = dataNoPassado.before(dataNoFuturo);

        System.out.println(isBefore);
        //true

        /** Trecho adicionado pelo Gelson em 10/02/2021*/

        /** pegando o time millis do dia do meu nascimento e 15 de maio de 2010 */
        String myBornDate = "1979/09/26 10:00:00";
        SimpleDateFormat sdfB = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date dateN = sdfB.parse(myBornDate);
        long bornDateMillis = dateN.getTime();

        String compareDate = "2010/05/15 10:00:00";
        SimpleDateFormat sdfC = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date dateC = sdfC.parse(compareDate);
        long compareDateMillis = dateC.getTime();

        /** Convertendo para Date e comparando se é antes ou depois de 15 de maio de 2010 */
        System.out.println("Data do meu nascimento é anterior à 15 de maio de 2010 = "
                            + new Date(bornDateMillis).before(new Date(compareDateMillis)));
        System.out.println("Data do meu nascimento é posterior à 15 de maio de 2010 = "
                            + new Date(bornDateMillis).after(new Date(compareDateMillis)));

        System.out.println();
    }
}
